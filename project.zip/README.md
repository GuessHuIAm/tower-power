User guide:

Our video guide: https://youtu.be/xDHAK_RgHP8

To run:
1. Install pygame by inputting pip install pygame in the terminal
2. Input python main.py in the terminal

To play:
INTRO SCREEN: Press any key to proceed to the Selection Screen.

SELECTION SCREEN: Click on a level to choose which level you wish to play. With each higher level, you get less coins and/or lives.

GAMEPLAY: You will be given a certain number of coins at the start of the level to spend on plants. Enemies will be spawned, and will enter from the right side of the grid. 

Click on a packet on top, then click on anywhere in the grid to plant a tower. 

The carrot shoots mini carrots as bullets against the enemies. 

The potato partition acts as a wall against enemies.

Everytime an enemy reaches the left side of the grid, your lives will decrease by 1. If your lives decrease to 0, you lose the game. If you successfully kill all the enemies, you win the game.


